<?php print drupal_render_children($form) ?>
<div class='buttons'><?php print drupal_render($buttons) ?></div>
