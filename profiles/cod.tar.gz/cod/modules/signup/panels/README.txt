This directory contains the files necessary to provide integration
between the signup module and the panels module.  For more information
about panels, see the project page: http://drupal.org/project/panels.
