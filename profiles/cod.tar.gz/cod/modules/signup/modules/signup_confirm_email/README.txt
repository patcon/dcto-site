The Signup confirm e-mail module (signup_email_confirm) injects an
e-mail address field on the signup form for authenticated users to
verify the address stored in their profile.  If the user changes this
field while signing up (or editing an existing signup), they are
presented with a confirmation form.  If they approve, the e-mail
address in their profile is updated.

There are no settings or permissions associated with this module.  If
you want this functionality, simply enable the module.

