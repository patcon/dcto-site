COD Alpha3
COD is the Conference Organizing Distribution of Drupal.
For more information, see http://usecod.com and @usecod on Twitter (http://twitter.com/usecod).
To report issues or get support, visit http://drupal.org/project/cod_support or #drupal-cod on IRC.